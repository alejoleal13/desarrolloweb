export class Tweet {
    id: number;
    texto: string;
    autor: string;
   }
   