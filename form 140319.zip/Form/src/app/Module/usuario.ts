export class usuario {
    nombre: string;
    telefono: number;
    correo: string;
    usuario: string
   }